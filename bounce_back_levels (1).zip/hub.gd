extends CanvasLayer

var player
var score_label
var coin_label
var plate_label
var level_label
var mama_bar
var message
var message_bg
var blink_time := 0.0
var level_label
var end_screen

func _ready():
	add_to_group("hud")
	player = get_parent().get_node("Player")

	var bar = ColorRect.new()
	bar.color = Color("#3b2a1e")
	bar.size = Vector2(540, 72)
	add_child(bar)

	score_label = make_label(self, Vector2(16, 8), 22)
	coin_label = make_label(self, Vector2(200, 8), 22)
	plate_label = make_label(self, Vector2(360, 8), 22)

	mama_bar = ProgressBar.new()
	mama_bar.position = Vector2(16, 44)
	mama_bar.size = Vector2(300, 18)
	mama_bar.max_value = 1.0
	mama_bar.step = 0.01
	mama_bar.show_percentage = false
	mama_bar.modulate = Color("#ff7b5c")
	add_child(mama_bar)
	var m = make_label(self, Vector2(326, 38), 20)
	m.text = "Mama"
	level_label = make_label(self, Vector2(420, 38), 20)
	level_label.add_theme_color_override("font_color", Color("#ffd23f"))

	message_bg = ColorRect.new()
	message_bg.color = Color(0, 0, 0, 0.65)
	message_bg.position = Vector2(0, 300)
	message_bg.size = Vector2(540, 330)
	message_bg.visible = false
	add_child(message_bg)

	message = make_label(self, Vector2(0, 300), 28)
	message.size = Vector2(540, 330)
	message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	message.visible = false

func make_label(parent, pos, font_size, color := Color("#fff0d5"), outline := 6):
	var l = Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", outline)
	parent.add_child(l)
	return l

func _process(delta):
	if player:
		score_label.text = "Score " + str(int(player.score))
		coin_label.text = "Coins " + str(player.coins)
		var main = get_parent()
		level_label.text = "Lv " + str(main.current_level)
		plate_label.text = "Plate " + str(player.plates) + "/" + str(main.plates_needed)
		mama_bar.value = 1.0 - player.mama_distance
		level_label.text = "Level " + str(get_parent().level)
	if message.visible and "Press" in message.text:
		blink_time += delta
		message.modulate.a = 0.6 + 0.4 * sin(blink_time * 5)
	else:
		message.modulate.a = 1.0

func show_message(t):
	message.text = t
	message.visible = true
	message_bg.visible = true

func hide_message():
	message.visible = false
	message_bg.visible = false

# ---------------------------------------------------------------- WIN / LOSE screen
func show_end_screen(d: Dictionary):
	hide_message()
	hide_end_screen()
	var win = d.get("win", false)
	var main_color = Color("#258b56") if win else Color("#b3261e")

	end_screen = Control.new()
	end_screen.size = Vector2(540, 960)
	add_child(end_screen)

	# colorful background with zellige stripes
	var bg = ColorRect.new()
	bg.color = Color("#f4a52a") if win else Color("#5b1f3a")
	bg.size = Vector2(540, 960)
	end_screen.add_child(bg)
	var cols = ["#185fa5", "#fff6e5", "#258b56", "#fff6e5"] if win else ["#b3261e", "#e8b923", "#7a2b52", "#e8b923"]
	for i in 27:
		for y in [0, 20, 920, 940]:
			var tile = ColorRect.new()
			tile.color = Color(cols[(i + y / 20) % 4])
			tile.position = Vector2(i * 20, y)
			tile.size = Vector2(20, 20)
			end_screen.add_child(tile)

	# cream card
	var card = Panel.new()
	var cs = StyleBoxFlat.new()
	cs.bg_color = Color("#fff6e5")
	cs.border_color = main_color
	cs.set_border_width_all(8)
	cs.set_corner_radius_all(24)
	card.add_theme_stylebox_override("panel", cs)
	card.position = Vector2(30, 70)
	card.size = Vector2(480, 820)
	end_screen.add_child(card)

	var title = make_label(end_screen, Vector2(30, 95), 34, main_color, 0)
	title.size = Vector2(480, 44)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text = d.get("title", "")
	var sub = make_label(end_screen, Vector2(30, 145), 20, Color("#6b4a2a"), 0)
	sub.size = Vector2(480, 30)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.text = d.get("subtitle", "")

	# the picture
	var pic_path = "res://bounce_back_sprites/" + ("screen_win.png" if win else "screen_lose.png")
	if ResourceLoader.exists(pic_path):
		var pic = TextureRect.new()
		pic.texture = load(pic_path)
		pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		pic.position = Vector2(120, 185)
		pic.size = Vector2(300, 246)
		end_screen.add_child(pic)
		var bounce = create_tween().set_loops()
		bounce.tween_property(pic, "position:y", 175.0, 0.6).set_trans(Tween.TRANS_SINE)
		bounce.tween_property(pic, "position:y", 185.0, 0.6).set_trans(Tween.TRANS_SINE)

	# score lines
	var stats = make_label(end_screen, Vector2(30, 445), 26, Color("#3b2a1e"), 0)
	stats.size = Vector2(480, 130)
	stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats.text = d.get("stats", "")

	# the gift (win only)
	if win and d.has("gift_name"):
		var box = Panel.new()
		var bs = StyleBoxFlat.new()
		bs.bg_color = Color("#fdf0c4")
		bs.border_color = Color("#e8b923")
		bs.set_border_width_all(4)
		bs.set_corner_radius_all(14)
		box.add_theme_stylebox_override("panel", bs)
		box.position = Vector2(80, 590)
		box.size = Vector2(380, 120)
		end_screen.add_child(box)
		var gpath = d.get("gift_tex", "")
		if ResourceLoader.exists(gpath):
			var tex = load(gpath)
			var g = TextureRect.new()
			if gpath.ends_with("_run.png"):    # show only the first frame of the outfit strip
				var at = AtlasTexture.new()
				at.atlas = tex
				at.region = Rect2(0, 0, 32, tex.get_height())
				g.texture = at
			else:
				g.texture = tex
			g.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			g.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			g.position = Vector2(95, 597)
			g.size = Vector2(90, 106)
			end_screen.add_child(g)
		var gl = make_label(end_screen, Vector2(190, 605), 22, Color("#633806"), 0)
		gl.size = Vector2(260, 90)
		gl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		gl.text = "GIFT UNLOCKED!\n" + d["gift_name"]

	# buttons
	var y = 735
	var first = null
	for b in d.get("buttons", []):
		var btn = Button.new()
		btn.text = b[0]
		btn.position = Vector2(80, y)
		btn.size = Vector2(380, 60)
		btn.add_theme_font_size_override("font_size", 24)
		btn.add_theme_color_override("font_color", Color.WHITE)
		btn.add_theme_color_override("font_hover_color", Color.WHITE)
		btn.add_theme_color_override("font_focus_color", Color.WHITE)
		btn.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.5))
		btn.add_theme_constant_override("outline_size", 4)
		for st in ["normal", "hover", "pressed", "focus"]:
			var s = StyleBoxFlat.new()
			var c = Color(b[2])
			s.bg_color = c.lightened(0.15) if st == "hover" else (c.darkened(0.15) if st == "pressed" else c)
			s.set_corner_radius_all(16)
			s.border_color = Color.WHITE if st == "focus" else c.darkened(0.3)
			s.set_border_width_all(4 if st == "focus" else 3)
			btn.add_theme_stylebox_override(st, s)
		btn.pressed.connect(b[1])
		end_screen.add_child(btn)
		if first == null:
			first = btn
		y += 75
	if first:
		first.grab_focus()   # SPACE / ENTER presses the first button

	if win:
		confetti()

func confetti():
	var colors = ["#e24b4a", "#258b56", "#185fa5", "#e8b923", "#d4537e", "#fff6e5"]
	for i in 60:
		var c = ColorRect.new()
		c.color = Color(colors.pick_random())
		c.size = Vector2(8, 12)
		c.position = Vector2(randf_range(0, 540), randf_range(-400, -20))
		c.rotation = randf_range(0, 3)
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE
		end_screen.add_child(c)
		var t = create_tween()
		t.tween_property(c, "position:y", 1000.0, randf_range(2.0, 4.0))
		t.parallel().tween_property(c, "rotation", c.rotation + randf_range(4, 10), 3.0)
		t.tween_callback(c.queue_free)

func hide_end_screen():
	if end_screen and is_instance_valid(end_screen):
		end_screen.queue_free()
	end_screen = null
